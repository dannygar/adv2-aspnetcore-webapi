/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See LICENSE in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
namespace Web.Api
{
    public class ApiRoutes
    {
        //Version 1.0
        public const string WeatherRoute = "api/v1/weather";
    }
}
